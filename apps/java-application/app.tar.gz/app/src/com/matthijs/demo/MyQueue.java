package com.matthijs.demo;

import org.slf4j.LoggerFactory;
import java.util.UUID;
import java.util.HashMap;
import java.util.ArrayList;
import org.slf4j.Logger;

public class MyQueue
{
    private static final Logger log;
    private ArrayList<MyTask> queue;
    private HashMap<UUID, MyTask> ackSet;
    public HashMap<UUID, MyJob> ackJobs;
    private ArrayList<MyTask> finishedTasks;
    
    public MyQueue() {
        this.queue = new ArrayList<MyTask>();
        this.ackSet = new HashMap<UUID, MyTask>();
        this.finishedTasks = new ArrayList<MyTask>();
        this.ackJobs = new HashMap<UUID, MyJob>();
    }
    
    public int getLength() {
        return this.queue.size();
    }
    
    public double getArrivalRate() {
        final int size = this.queue.size();
        if (size == 0) {
            return 0.0;
        }
        if (size == 1) {
            return 1.0;
        }
        MyTask t;
        final double firstInQueue = ((t = this.queue.get(0)) != null) ? ((double)t.arrivalQueueTime) : 0.0;
        final double lastInQueue = ((t = this.queue.get(size - 1)) != null) ? ((double)t.arrivalQueueTime) : 0.0;
        MyQueue.log.info("arrival rate {},{},{}" + firstInQueue, (Object)lastInQueue, (Object)(lastInQueue - firstInQueue));
        return size / ((lastInQueue - firstInQueue) / 60000.0);
    }
    
    public double getProcessingRate() {
        final int size = this.finishedTasks.size();
        if (size == 0) {
            return 0.0;
        }
        if (size == 1) {
            return 1.0;
        }
        MyTask t;
        final double firstInQueue = ((t = this.finishedTasks.get(0)) != null) ? ((double)t.ackQueueTime) : 0.0;
        final double lastInQueue = ((t = this.finishedTasks.get(size - 1)) != null) ? ((double)t.ackQueueTime) : 0.0;
        MyQueue.log.info("processing rate {},{},{}" + firstInQueue, (Object)lastInQueue, (Object)(lastInQueue - firstInQueue));
        return size / ((lastInQueue - firstInQueue) / 60000.0);
    }
    
    public double getResponseTime() {
        long totalResponseTime = 0L;
        int total = 0;
        if (!this.finishedTasks.isEmpty()) {
            ++total;
            totalResponseTime = this.finishedTasks.get(this.finishedTasks.size() - 1).getResponsTime();
        }
        if (total == 0) {
            return 0.0;
        }
        return totalResponseTime / (double)total;
    }
    
    public double getQueueOutputRate() {
        final int size = this.finishedTasks.size();
        if (size == 0) {
            return 0.0;
        }
        if (size == 1) {
            return 1.0;
        }
        MyTask t;
        final double firstInQueue = ((t = this.finishedTasks.get(0)) != null) ? ((double)t.leaveQueueTime) : 0.0;
        final double lastInQueue = ((t = this.finishedTasks.get(size - 1)) != null) ? ((double)t.leaveQueueTime) : 0.0;
        MyQueue.log.info("output rate {},{},{}" + firstInQueue, (Object)lastInQueue, (Object)(lastInQueue - firstInQueue));
        return size / ((lastInQueue - firstInQueue) / 60000.0);
    }
    
    public void addNewTask(final int tasks) {
        for (int i = 0; i < tasks; ++i) {
            this.queue.add(new MyTask());
        }
        final UUID id = UUID.randomUUID();
        MyQueue.log.info("Added " + tasks + " tasks.");
    }
    
    private synchronized void addTask(final MyTask t) {
        this.queue.add(t);
    }
    
    private synchronized MyTask getFirstTask() {
        if (!this.queue.isEmpty()) {
            return this.queue.remove(0);
        }
        return null;
    }
    
    public void addNewJob(final MyJob job) {
        this.ackJobs.put(job.id, job);
        for (int i = 0; i < job.totalTasks; ++i) {
            this.addTask(new MyTask(job.id));
        }
        MyQueue.log.info("New job added with " + job.totalTasks + "tasks");
    }
    
    public MyTask getFirstTask(final UUID piggybackedAck) {
        if (piggybackedAck != null) {
            this.markAck(piggybackedAck);
        }
        if (!this.queue.isEmpty()) {
            final MyTask t = this.getFirstTask();
            if (t != null) {
                t.leftQueue();
                this.ackSet.put(t.id, t);
                return t;
            }
        }
        return null;
    }
    
    private void markAck(final UUID ack) {
        final MyTask t = this.ackSet.remove(ack);
        if (t != null && t.jobId != null) {
            this.checkJobCompleted(t.jobId);
        }
        if (t != null) {
            t.markAck();
        }
    }
    
    private void checkJobCompleted(final UUID jobid) {
        final MyJob job = this.ackJobs.get(jobid);
        if (job != null) {
            job.completeTask();
            if (job.isCompleted()) {
                this.ackJobs.remove(jobid);
            }
        }
    }
    
    static {
        log = LoggerFactory.getLogger((Class)MyQueue.class);
    }
}