// 
// Decompiled by Procyon v0.5.36
// 

package com.matthijs.demo;

import org.slf4j.LoggerFactory;
import com.matthijs.rabbit.Message;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import com.matthijs.rabbit.MessageSender;

public class UserCount
{
    @Autowired
    private MessageSender sender;
    @Value("${pod.name}")
    private String podName;
    @Value("${pod.namespace}")
    private String namespace;
    private static final Logger log;
    
    public void loginUser() {
        final Message message = new Message(this.namespace, this.podName, "added");
        this.sender.sendMessage(message, "job.added");
        UserCount.log.info("Added user.");
    }
    
    public void logoutUser() {
        final Message message = new Message(this.namespace, this.podName, "completed");
        this.sender.sendMessage(message, "job.completed");
        UserCount.log.info("Removed user.");
    }
    
    static {
        log = LoggerFactory.getLogger((Class)SimpleController.class);
    }
}