package com.matthijs.demo;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class MyJob
{
    private CompletableFuture<String> future;
    public int todos;
    public int totalTasks;
    public UUID id;
    
    public MyJob(final int amountOfTasks) {
        this.todos = 0;
        this.totalTasks = 0;
        this.totalTasks = amountOfTasks;
        this.todos = amountOfTasks;
        this.future = new CompletableFuture<String>();
        this.id = UUID.randomUUID();
    }
    
    public synchronized void completeTask() {
        --this.todos;
        if (this.todos <= 0) {
            this.future.complete("completed all tasks");
        }
    }
    
    public synchronized boolean isCompleted() {
        return this.todos <= 0;
    }
    
    public CompletableFuture<String> getFuture() {
        return this.future;
    }
}