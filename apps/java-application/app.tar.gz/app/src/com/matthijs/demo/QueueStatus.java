package com.matthijs.demo;

import java.util.Collection;

public class QueueStatus
{
    public int queueLength;
    public int acklength;
    public double arrivalRate;
    public double processingRate;
    public double outputRate;
    public double reponseTime;
    public Collection<MyJob> jobs;
    
    public QueueStatus() {
        this.queueLength = 0;
        this.acklength = 0;
        this.arrivalRate = 0.0;
        this.processingRate = 0.0;
        this.outputRate = 0.0;
        this.jobs = null;
    }
}