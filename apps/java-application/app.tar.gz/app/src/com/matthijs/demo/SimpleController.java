package com.matthijs.demo;

import org.slf4j.LoggerFactory;
import java.util.UUID;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.concurrent.Future;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SimpleController
{
    @Autowired
    private MyQueue q;
    @Autowired
    private UserCount uc;
    private static final Logger log;
    
    @Autowired
    public SimpleController() {
    }
    
    @RequestMapping({ "/login" })
    public String login() {
        this.uc.loginUser();
        return "User registered";
    }
    
    @RequestMapping({ "/logout" })
    public String logout() {
        this.uc.logoutUser();
        return "Logout";
    }
    
    @RequestMapping({ "/push" })
    public String push() {
        this.q.addNewTask(10000);
        return "Queue length " + this.q.getLength();
    }
    
    @RequestMapping({ "/pushJob/{amount}" })
    public Future<String> pushJob(@PathVariable final int amount) {
        final MyJob job = new MyJob(amount);
        this.q.addNewJob(job);
        return (Future<String>)job.getFuture();
    }
    
    @RequestMapping({ "/pull" })
    public MyTask pull(@RequestParam(value = "ack", defaultValue = "") final String ack) {
        final UUID ackUUID = this.getUUIDFromString(ack);
        if (ackUUID != null) {
            SimpleController.log.info("piggybacked uuid " + ackUUID);
        }
        final MyTask t = this.q.getFirstTask(ackUUID);
        if (t != null) {
            return t;
        }
        return new MyTask(true);
    }
    
    @RequestMapping({ "/status" })
    public QueueStatus QueueStatus() {
        final QueueStatus s = new QueueStatus();
        s.queueLength = this.q.getLength();
        s.acklength = this.q.ackJobs.size();
        s.arrivalRate = this.q.getArrivalRate();
        s.processingRate = this.q.getProcessingRate();
        s.outputRate = this.q.getQueueOutputRate();
        s.reponseTime = this.q.getResponseTime();
        s.jobs = this.q.ackJobs.values();
        return s;
    }
    
    private UUID getUUIDFromString(final String input) {
        UUID ackUUID = null;
        try {
            ackUUID = UUID.fromString(input);
        }
        catch (IllegalArgumentException e) {
            return null;
        }
        return ackUUID;
    }
    
    static {
        log = LoggerFactory.getLogger((Class)SimpleController.class);
    }
}