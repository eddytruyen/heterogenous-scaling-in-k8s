package com.matthijs;

import com.matthijs.demo.UserCount;
import org.springframework.context.annotation.Bean;
import com.matthijs.demo.MyQueue;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication
{
    public static void main(final String[] args) {
        SpringApplication.run((Object)DemoApplication.class, args);
    }
    
    @Bean
    public MyQueue getQueue() {
        return new MyQueue();
    }
    
    @Bean
    public UserCount getUserCount() {
        return new UserCount();
    }
}