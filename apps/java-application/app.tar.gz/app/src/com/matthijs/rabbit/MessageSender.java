
@Service
public class MessageSender
{
    private final RabbitTemplate rabbitTemplate;
    private static final Logger logger;
    
    @Autowired
    public MessageSender(final RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }
    
    public void sendMessage(final Message message, final String routingKey) {
        final String exchangeName = "non_linear_scaler";
        MessageSender.logger.info("Sending message in exchange: " + exchangeName + " with topic: " + routingKey);
        try {
            this.rabbitTemplate.convertAndSend(exchangeName, routingKey, (Object)message);
        }
        catch (Exception e) {
            MessageSender.logger.info("There was an error when sending the message: " + e);
        }
    }
    
    static {
        logger = LoggerFactory.getLogger((Class)MessageSender.class);
    }
}